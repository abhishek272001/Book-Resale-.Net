﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class List : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (Session["Id"] != null && !string.IsNullOrEmpty(ViewState["BookId"].ToString()))
        {
            string Id = Session["Id"].ToString();
            string BookId = Session["BookId"].ToString();
            using (SqlCommand cmd = new SqlCommand("INSERT INTO Ordertbl (Id,BookId)VALUES(@UserID,@ProductId)", con))
            {
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@UserId", Id);
                cmd.Parameters.AddWithValue("@ProductId", BookId);
            }
        }
        else
        {
            Response.Redirect("login.aspx");
        }
    }

    public SqlConnection con { get; set; }
}