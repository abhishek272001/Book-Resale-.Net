﻿//function myFunction() {
//    alert("You are registered");
//    window.location.href="Register.aspx";
//}